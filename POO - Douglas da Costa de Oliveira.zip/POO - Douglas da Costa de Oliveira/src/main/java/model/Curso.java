package model;

/**
 * Lado "N" da associação: cada curso está vinculado a um único departamento.
 */
public class Curso {

    private int id;
    private String codigo;
    private String nome;
    private int cargaHorariaTotal;
    private Departamento departamento;

    public Curso() {
    }

    public Curso(String codigo, String nome, int cargaHorariaTotal, Departamento departamento) {
        this.codigo = codigo;
        this.nome = nome;
        this.cargaHorariaTotal = cargaHorariaTotal;
        this.departamento = departamento;
    }

    public Curso(int id, String codigo, String nome, int cargaHorariaTotal, Departamento departamento) {
        this(codigo, nome, cargaHorariaTotal, departamento);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCargaHorariaTotal() {
        return cargaHorariaTotal;
    }

    public void setCargaHorariaTotal(int cargaHorariaTotal) {
        this.cargaHorariaTotal = cargaHorariaTotal;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return "Curso{id=" + id
                + ", codigo='" + codigo + '\''
                + ", nome='" + nome + '\''
                + ", cargaHorariaTotal=" + cargaHorariaTotal
                + ", departamento='" + (departamento != null ? departamento.getSigla() : null) + '\''
                + '}';
    }
}
