package model;

/**
 * Lado "1" da associação: um departamento abriga vários cursos.
 */
public class Departamento {

    private int id;
    private String nome;
    private String sigla;
    private String bloco;

    public Departamento() {
    }

    public Departamento(String nome, String sigla, String bloco) {
        this.nome = nome;
        this.sigla = sigla;
        this.bloco = bloco;
    }

    public Departamento(int id, String nome, String sigla, String bloco) {
        this(nome, sigla, bloco);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getBloco() {
        return bloco;
    }

    public void setBloco(String bloco) {
        this.bloco = bloco;
    }

    @Override
    public String toString() {
        return "Departamento{id=" + id
                + ", nome='" + nome + '\''
                + ", sigla='" + sigla + '\''
                + ", bloco='" + bloco + '\''
                + '}';
    }
}
