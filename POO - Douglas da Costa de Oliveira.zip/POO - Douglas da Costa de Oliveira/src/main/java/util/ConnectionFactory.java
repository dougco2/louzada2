package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Fábrica de conexões com o PostgreSQL.
 * Os dados de acesso podem ser sobrescritos pelas variáveis de ambiente
 * DB_URL, DB_USER e DB_PASSWORD.
 */
public class ConnectionFactory {

    private static final String URL = lerVariavel("DB_URL", "jdbc:postgresql://localhost:5432/poo_exercicios");
    private static final String USUARIO = lerVariavel("DB_USER", "postgres");
    private static final String SENHA = lerVariavel("DB_PASSWORD", "postgres");

    private ConnectionFactory() {
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver do PostgreSQL (org.postgresql.Driver) não encontrado.", e);
        }
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }

    private static String lerVariavel(String nome, String valorPadrao) {
        String valor = System.getenv(nome);
        return (valor == null || valor.isBlank()) ? valorPadrao : valor;
    }
}
