package app;

import dao.CursoDAO;
import dao.DAOException;
import dao.DepartamentoDAO;
import model.Curso;
import model.Departamento;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        DepartamentoDAO departamentoDAO = new DepartamentoDAO();
        CursoDAO cursoDAO = new CursoDAO();

        try {
            titulo("1. Inserindo departamentos (lado 1)");
            Departamento computacao = new Departamento("Departamento de Computação", "DCOMP", "Bloco C");
            Departamento engenharia = new Departamento("Departamento de Engenharia", "DENG", "Bloco E");
            departamentoDAO.salvar(computacao);
            departamentoDAO.salvar(engenharia);
            System.out.println("Salvo: " + computacao);
            System.out.println("Salvo: " + engenharia);

            titulo("2. Inserindo cursos (lado N) associados aos departamentos");
            Curso cienciaComputacao = new Curso("CC-01", "Ciência da Computação", 3200, computacao);
            Curso mestradoInformatica = new Curso("PPGI-01", "Mestrado em Informática", 960, computacao);
            Curso engenhariaCivil = new Curso("EC-01", "Engenharia Civil", 3600, engenharia);
            cursoDAO.salvar(cienciaComputacao);
            cursoDAO.salvar(mestradoInformatica);
            cursoDAO.salvar(engenhariaCivil);
            System.out.println("Salvo: " + cienciaComputacao);
            System.out.println("Salvo: " + mestradoInformatica);
            System.out.println("Salvo: " + engenhariaCivil);

            titulo("3. Listando todos os cursos com seu departamento (INNER JOIN)");
            imprimirCursos(cursoDAO.listarTodos());

            titulo("4. Cursos do departamento " + computacao.getSigla());
            imprimirCursos(cursoDAO.listarPorDepartamento(computacao.getId()));

            titulo("5. Buscando por ID");
            System.out.println(departamentoDAO.buscarPorId(engenharia.getId()));
            System.out.println(cursoDAO.buscarPorId(engenhariaCivil.getId()));

            titulo("6. Atualizando registros");
            computacao.setBloco("Bloco C - Anexo");
            departamentoDAO.atualizar(computacao);
            cienciaComputacao.setCargaHorariaTotal(3400);
            cienciaComputacao.setNome("Bacharelado em Ciência da Computação");
            cursoDAO.atualizar(cienciaComputacao);
            System.out.println("Após atualizar: " + departamentoDAO.buscarPorId(computacao.getId()));
            System.out.println("Após atualizar: " + cursoDAO.buscarPorId(cienciaComputacao.getId()));

            titulo("7. Testando a integridade referencial (ON DELETE RESTRICT)");
            try {
                departamentoDAO.deletar(computacao.getId());
                System.out.println("ATENÇÃO: o departamento foi removido mesmo tendo cursos!");
            } catch (DAOException e) {
                System.out.println("Exclusão bloqueada pelo banco, pois o departamento ainda possui cursos.");
                System.out.println("Mensagem: " + e.getMessage());
            }

            titulo("8. Removendo registros");
            cursoDAO.deletar(cienciaComputacao.getId());
            cursoDAO.deletar(mestradoInformatica.getId());
            cursoDAO.deletar(engenhariaCivil.getId());
            System.out.println("Cursos removidos.");
            departamentoDAO.deletar(computacao.getId());
            departamentoDAO.deletar(engenharia.getId());
            System.out.println("Departamentos removidos (agora sem cursos vinculados).");

            titulo("9. Situação final do banco");
            System.out.println("Departamentos cadastrados: " + departamentoDAO.listarTodos().size());
            System.out.println("Cursos cadastrados: " + cursoDAO.listarTodos().size());

        } catch (DAOException e) {
            System.err.println("Erro de acesso ao banco de dados: " + e.getMessage());
        }
    }

    private static void imprimirCursos(List<Curso> cursos) {
        if (cursos.isEmpty()) {
            System.out.println("(nenhum curso encontrado)");
            return;
        }
        for (Curso c : cursos) {
            System.out.printf("#%d %-8s %-38s | %5d h | Depto: %s - %s (%s)%n",
                    c.getId(), c.getCodigo(), c.getNome(), c.getCargaHorariaTotal(),
                    c.getDepartamento().getSigla(), c.getDepartamento().getNome(),
                    c.getDepartamento().getBloco());
        }
    }

    private static void titulo(String texto) {
        System.out.println();
        System.out.println("=== " + texto + " ===");
    }
}
