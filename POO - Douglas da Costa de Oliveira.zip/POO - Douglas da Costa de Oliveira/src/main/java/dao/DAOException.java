package dao;

/**
 * Exceção lançada pelos DAOs quando ocorre uma SQLException,
 * preservando a causa original.
 */
public class DAOException extends RuntimeException {

    public DAOException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
