package dao;

import model.Departamento;
import util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DepartamentoDAO {

    public void salvar(Departamento departamento) {
        String sql = "INSERT INTO departamento (nome, sigla, bloco) VALUES (?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, departamento.getNome());
            ps.setString(2, departamento.getSigla());
            ps.setString(3, departamento.getBloco());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    departamento.setId(rs.getInt("id"));
                }
            }
        } catch (SQLException e) {
            throw new DAOException("Erro ao salvar departamento: " + e.getMessage(), e);
        }
    }

    public Departamento buscarPorId(int id) {
        String sql = "SELECT id, nome, sigla, bloco FROM departamento WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        } catch (SQLException e) {
            throw new DAOException("Erro ao buscar departamento por id: " + e.getMessage(), e);
        }
    }

    public List<Departamento> listarTodos() {
        String sql = "SELECT id, nome, sigla, bloco FROM departamento ORDER BY nome";
        List<Departamento> departamentos = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                departamentos.add(mapear(rs));
            }
        } catch (SQLException e) {
            throw new DAOException("Erro ao listar departamentos: " + e.getMessage(), e);
        }
        return departamentos;
    }

    public boolean atualizar(Departamento departamento) {
        String sql = "UPDATE departamento SET nome = ?, sigla = ?, bloco = ? WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, departamento.getNome());
            ps.setString(2, departamento.getSigla());
            ps.setString(3, departamento.getBloco());
            ps.setInt(4, departamento.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Erro ao atualizar departamento: " + e.getMessage(), e);
        }
    }

    public boolean deletar(int id) {
        String sql = "DELETE FROM departamento WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Erro ao deletar departamento: " + e.getMessage(), e);
        }
    }

    private Departamento mapear(ResultSet rs) throws SQLException {
        return new Departamento(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("sigla"),
                rs.getString("bloco"));
    }
}
