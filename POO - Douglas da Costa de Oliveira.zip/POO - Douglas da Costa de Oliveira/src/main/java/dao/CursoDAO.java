package dao;

import model.Curso;
import model.Departamento;
import util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CursoDAO {

    private static final String SELECT_COM_JOIN =
            "SELECT c.id, c.codigo, c.nome, c.carga_horaria_total, "
            + "d.id AS departamento_id, d.nome AS departamento_nome, d.sigla, d.bloco "
            + "FROM curso c "
            + "INNER JOIN departamento d ON d.id = c.departamento_id ";

    public void salvar(Curso curso) {
        String sql = "INSERT INTO curso (codigo, nome, carga_horaria_total, departamento_id) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            preencherCampos(ps, curso);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    curso.setId(rs.getInt("id"));
                }
            }
        } catch (SQLException e) {
            throw new DAOException("Erro ao salvar curso: " + e.getMessage(), e);
        }
    }

    public Curso buscarPorId(int id) {
        String sql = SELECT_COM_JOIN + "WHERE c.id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        } catch (SQLException e) {
            throw new DAOException("Erro ao buscar curso por id: " + e.getMessage(), e);
        }
    }

    /** Lista todos os cursos com os dados do departamento (INNER JOIN). */
    public List<Curso> listarTodos() {
        String sql = SELECT_COM_JOIN + "ORDER BY d.sigla, c.nome";
        List<Curso> cursos = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                cursos.add(mapear(rs));
            }
        } catch (SQLException e) {
            throw new DAOException("Erro ao listar cursos: " + e.getMessage(), e);
        }
        return cursos;
    }

    /** Lista os cursos oferecidos por um departamento específico (INNER JOIN). */
    public List<Curso> listarPorDepartamento(int departamentoId) {
        String sql = SELECT_COM_JOIN + "WHERE d.id = ? ORDER BY c.nome";
        List<Curso> cursos = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, departamentoId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cursos.add(mapear(rs));
                }
            }
        } catch (SQLException e) {
            throw new DAOException("Erro ao listar cursos do departamento: " + e.getMessage(), e);
        }
        return cursos;
    }

    public boolean atualizar(Curso curso) {
        String sql = "UPDATE curso SET codigo = ?, nome = ?, carga_horaria_total = ?, departamento_id = ? WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            preencherCampos(ps, curso);
            ps.setInt(5, curso.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Erro ao atualizar curso: " + e.getMessage(), e);
        }
    }

    public boolean deletar(int id) {
        String sql = "DELETE FROM curso WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DAOException("Erro ao deletar curso: " + e.getMessage(), e);
        }
    }

    private void preencherCampos(PreparedStatement ps, Curso curso) throws SQLException {
        if (curso.getDepartamento() == null) {
            throw new IllegalArgumentException("O curso precisa estar associado a um departamento.");
        }
        ps.setString(1, curso.getCodigo());
        ps.setString(2, curso.getNome());
        ps.setInt(3, curso.getCargaHorariaTotal());
        ps.setInt(4, curso.getDepartamento().getId());
    }

    private Curso mapear(ResultSet rs) throws SQLException {
        Departamento departamento = new Departamento(
                rs.getInt("departamento_id"),
                rs.getString("departamento_nome"),
                rs.getString("sigla"),
                rs.getString("bloco"));

        return new Curso(
                rs.getInt("id"),
                rs.getString("codigo"),
                rs.getString("nome"),
                rs.getInt("carga_horaria_total"),
                departamento);
    }
}
