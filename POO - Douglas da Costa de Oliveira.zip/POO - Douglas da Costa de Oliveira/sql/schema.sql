-- Estudo de Caso 3: Sistema de Gestão Acadêmica Universitária
-- Executar dentro do banco poo_exercicios (CREATE DATABASE poo_exercicios;)

CREATE TABLE departamento (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    sigla VARCHAR(10) UNIQUE NOT NULL,
    bloco VARCHAR(30)
);

CREATE TABLE curso (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(20) UNIQUE NOT NULL,
    nome VARCHAR(120) NOT NULL,
    carga_horaria_total INT NOT NULL,
    departamento_id INT NOT NULL REFERENCES departamento(id) ON DELETE RESTRICT
);
